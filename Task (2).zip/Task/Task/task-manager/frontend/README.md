### run the project code

extract file

open vs code/open the task folder/open the new terminal/again open the new terminal/1.terminal-(type)cd frontend/2.terminal-(type)cd Backend/1.terminal-type(node server.js)/2.terminal-type(npm i)/npm start.-run the project

### run the code after

(run the window page)

mobile view- (ctrl+shift+i)

select the options
