import React from 'react';
import { Check, Clock, Edit2, Trash2, Flag } from 'lucide-react';
import { formatDate, getPriorityColor } from '../utils/helpers';

const TaskItem = ({ task, onToggleComplete, onEdit, onDelete }) => {
  const PriorityIcon = ({ priority }) => {
    const props = { size: 16 };
    switch (priority) {
      case 'high':
        return <Flag {...props} className="text-red-500 fill-red-500" />;
      case 'medium':
        return <Flag {...props} className="text-yellow-500 fill-yellow-500" />;
      case 'low':
        return <Flag {...props} className="text-green-500 fill-green-500" />;
      default:
        return <Flag {...props} className="text-gray-400" />;
    }
  };

  const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && !task.completed;

  return (
    <div className={`card p-4 transition-all duration-200 hover:shadow-md ${
      task.completed ? 'bg-gray-50 opacity-75' : ''
    }`}>
      <div className="flex items-start gap-3">
        <button
          onClick={() => onToggleComplete(task.id, !task.completed)}
          className={`flex-shrink-0 w-5 h-5 rounded-full border-2 mt-1 transition-colors ${
            task.completed
              ? 'bg-green-500 border-green-500 text-white'
              : 'border-gray-300 hover:border-green-500'
          }`}
        >
          {task.completed && <Check size={12} className="m-auto" />}
        </button>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <PriorityIcon priority={task.priority} />
            <h3 className={`font-medium truncate ${
              task.completed ? 'line-through text-gray-500' : 'text-gray-900'
            }`}>
              {task.title}
            </h3>
          </div>
          
          {task.description && (
            <p className={`text-sm text-gray-600 mb-2 ${
              task.completed ? 'line-through' : ''
            }`}>
              {task.description}
            </p>
          )}

          <div className="flex items-center gap-4 text-xs text-gray-500">
            <div className="flex items-center gap-1">
              <Clock size={12} />
              <span className={isOverdue ? 'text-red-500 font-medium' : ''}>
                {formatDate(task.dueDate)}
              </span>
            </div>
            <span className={`px-2 py-1 rounded-full border ${getPriorityColor(task.priority)}`}>
              {task.priority}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1 flex-shrink-0">
          <button
            onClick={() => onEdit(task)}
            className="p-2 text-gray-400 hover:text-blue-500 transition-colors"
            title="Edit task"
          >
            <Edit2 size={16} />
          </button>
          <button
            onClick={() => onDelete(task.id)}
            className="p-2 text-gray-400 hover:text-red-500 transition-colors"
            title="Delete task"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskItem;