import React from 'react';
import { CheckSquare, Plus } from 'lucide-react';

const Header = ({ onAddTask, taskCount, completedCount }) => {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <CheckSquare size={24} className="text-blue-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Task Manager Pro</h1>
              <p className="text-gray-600">
                {completedCount} of {taskCount} tasks completed
              </p>
            </div>
          </div>
          
          <button
            onClick={onAddTask}
            className="btn-primary flex items-center gap-2 w-full sm:w-auto justify-center"
          >
            <Plus size={20} />
            Add Task
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;