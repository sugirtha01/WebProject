import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import FilterBar from './components/FilterBar';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import { taskService } from './services/api';
import { filterTasks } from './utils/helpers';

function App() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  // Load tasks on component mount
  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    try {
      setLoading(true);
      setError('');
      const response = await taskService.getAllTasks();
      setTasks(response.data || []);
    } catch (err) {
      console.error('Error loading tasks:', err);
      setError('Failed to load tasks. Please check if the server is running.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddTask = () => {
    setEditingTask(null);
    setShowTaskForm(true);
  };

  const handleEditTask = (task) => {
    setEditingTask(task);
    setShowTaskForm(true);
  };

  const handleCloseTaskForm = () => {
    setShowTaskForm(false);
    setEditingTask(null);
  };

  const handleSubmitTask = async (taskData) => {
    try {
      if (editingTask) {
        // Update existing task
        const response = await taskService.updateTask(editingTask.id, taskData);
        setTasks(prev => prev.map(task => 
          task.id === editingTask.id ? response.data : task
        ));
      } else {
        // Create new task
        const response = await taskService.createTask(taskData);
        setTasks(prev => [...prev, response.data]);
      }
      handleCloseTaskForm();
    } catch (err) {
      console.error('Error saving task:', err);
      setError(`Failed to save task: ${err.message}`);
    }
  };

  const handleToggleComplete = async (taskId, completed) => {
    try {
      const response = await taskService.updateTask(taskId, { completed });
      setTasks(prev => prev.map(task => 
        task.id === taskId ? response.data : task
      ));
    } catch (err) {
      console.error('Error updating task:', err);
      setError(`Failed to update task: ${err.message}`);
    }
  };

  const handleDeleteTask = async (taskId) => {
    if (!window.confirm('Are you sure you want to delete this task?')) {
      return;
    }

    try {
      await taskService.deleteTask(taskId);
      setTasks(prev => prev.filter(task => task.id !== taskId));
    } catch (err) {
      console.error('Error deleting task:', err);
      setError(`Failed to delete task: ${err.message}`);
    }
  };

  // Calculate task statistics
  const taskCount = tasks.length;
  const completedCount = tasks.filter(task => task.completed).length;

  // Filter tasks based on current filter and search query
  const filteredTasks = filterTasks(tasks, filter, searchQuery);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading tasks...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        onAddTask={handleAddTask}
        taskCount={taskCount}
        completedCount={completedCount}
      />
      
      <FilterBar 
        filter={filter}
        searchQuery={searchQuery}
        onFilterChange={setFilter}
        onSearchChange={setSearchQuery}
      />

      <main className="max-w-4xl mx-auto px-4 py-6">
        {error && (
          <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
            <p>{error}</p>
            <button 
              onClick={() => setError('')}
              className="mt-2 text-sm underline"
            >
              Dismiss
            </button>
          </div>
        )}

        <div className="mb-6 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-700">
            {filter === 'all' && 'All Tasks'}
            {filter === 'active' && 'Active Tasks'}
            {filter === 'completed' && 'Completed Tasks'}
            <span className="text-gray-500 ml-2">({filteredTasks.length})</span>
          </h2>
          
          {tasks.length > 0 && (
            <button
              onClick={loadTasks}
              className="text-sm text-blue-600 hover:text-blue-800"
            >
              Refresh
            </button>
          )}
        </div>

        <TaskList 
          tasks={filteredTasks}
          onToggleComplete={handleToggleComplete}
          onEdit={handleEditTask}
          onDelete={handleDeleteTask}
        />

        {tasks.length === 0 && !loading && (
          <div className="text-center py-12">
            <p className="text-gray-500 mb-4">No tasks yet. Create your first task!</p>
            <button onClick={handleAddTask} className="btn-primary">
              Create Your First Task
            </button>
          </div>
        )}
      </main>

      {showTaskForm && (
        <TaskForm 
          task={editingTask}
          onSubmit={handleSubmitTask}
          onCancel={handleCloseTaskForm}
          isEditing={!!editingTask}
        />
      )}
    </div>
  );
}

export default App;